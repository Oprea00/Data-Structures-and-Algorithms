#pragma once
#include<utility>

using namespace std;

typedef int TKey;
typedef int TValue;
typedef std::pair<TKey, TValue> TElem;
#define NULL_TVALUE -11111;

class DLLNode
{
private:
	TKey key;
	TValue value;
	DLLNode* prev;
	DLLNode* next;

public:
	DLLNode(TKey key = 0, TValue value = 0, DLLNode* prev = nullptr, DLLNode* next = nullptr);
};