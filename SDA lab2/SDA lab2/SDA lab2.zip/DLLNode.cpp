#include "DLLNode.h"

DLLNode::DLLNode(TKey key, TValue value, DLLNode* prev, DLLNode* next) : key(key), value(value), prev(prev), next(next) {}
